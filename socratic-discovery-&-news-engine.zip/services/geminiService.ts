
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { DiscoveryReport, AnswerLog, KnowledgeLevel, YouTubeVideo } from "../types";

const SEARCH_MODEL = 'gemini-3-flash-preview';
const SYNTHESIS_MODEL = 'gemini-3-pro-preview';
const IMAGE_MODEL = 'gemini-2.5-flash-image';

export class GeminiService {
  private getAI() {
    return new GoogleGenAI({ apiKey: process.env.API_KEY as string });
  }

  private async callWithRetry<T>(fn: (ai: GoogleGenAI) => Promise<T>, retries = 3, delay = 1500): Promise<T> {
    try {
      return await fn(this.getAI());
    } catch (error: any) {
      const errorStr = JSON.stringify(error).toLowerCase();
      const message = (error?.message || "").toLowerCase();
      const isRateLimit = 
        errorStr.includes('429') || 
        errorStr.includes('quota') || 
        errorStr.includes('limit') ||
        message.includes('quota') ||
        message.includes('limit');
      
      if (isRateLimit && retries > 0) {
        console.warn(`Rate limit hit. Retrying in ${delay}ms... (${retries} retries left)`);
        await new Promise(resolve => setTimeout(resolve, delay));
        // Exponential backoff
        return this.callWithRetry(fn, retries - 1, delay * 2.5);
      }
      throw error;
    }
  }

  private convertToEmbedUrl(url: string): string | null {
    if (!url) return null;
    try {
      const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i;
      const match = url.match(regex);
      const videoId = match ? match[1] : null;
      
      if (videoId) {
        return `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0&modestbranding=1&enablejsapi=1&origin=${window.location.origin}`;
      }
      return null;
    } catch (e) {
      console.error("Embed conversion failed:", e);
      return null;
    }
  }

  async initializeTopic(topic: string): Promise<{ hook: string; firstQuestion: string; totalQuestions: number }> {
    return this.callWithRetry(async (ai) => {
      const response = await ai.models.generateContent({
        model: SEARCH_MODEL,
        contents: `User is interested in: "${topic}". 
        Task: Start a Socratic session to analyze the user's interest, psychology, and behavior toward this topic.
        1. Provide a brief high-energy hook. 
        2. Plan exactly 5 questions.
        3. Ask the first question—focus on WHY they are interested or how they feel about the topic rather than what they know. 
        Return JSON.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              hook: { type: Type.STRING },
              firstQuestion: { type: Type.STRING },
              totalQuestions: { type: Type.NUMBER }
            },
            required: ["hook", "firstQuestion", "totalQuestions"]
          }
        }
      });

      return JSON.parse(response.text);
    });
  }

  async getNextQuestion(topic: string, history: AnswerLog[], currentIndex: number, total: number): Promise<{ validation: string; question: string }> {
    return this.callWithRetry(async (ai) => {
      const historyText = history.map(h => `Q: ${h.question}\nA: ${h.answer}`).join('\n\n');
      const response = await ai.models.generateContent({
        model: SEARCH_MODEL,
        contents: `Topic: ${topic}\nHistory:\n${historyText}\n
        Task: Continue analyzing the user's psychology and behavioral patterns regarding the topic.
        1. Briefly validate their previous psychological insight.
        2. Generate the next inquiry (Question ${currentIndex + 1} of ${total}).
        Focus on their mental model and emotional connection to the subject. Return JSON.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              validation: { type: Type.STRING },
              question: { type: Type.STRING }
            },
            required: ["validation", "question"]
          }
        }
      });
      return JSON.parse(response.text);
    });
  }

  async generateImage(topic: string, context: string): Promise<string | undefined> {
    return this.callWithRetry(async (ai) => {
      try {
        const response = await ai.models.generateContent({
          model: IMAGE_MODEL,
          contents: { parts: [{ text: `A professional, premium editorial illustration for "${topic}". Sleek minimalist aesthetic, deep cinematic tones. Context: ${context}` }] },
          config: { imageConfig: { aspectRatio: "16:9" } }
        });
        
        if (!response.candidates?.[0]?.content?.parts) {
          return undefined;
        }

        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
        }
      } catch (e) { 
        console.error("Image gen failed", e); 
      }
      return undefined;
    });
  }

  async generateFinalReport(topic: string, history: AnswerLog[]): Promise<DiscoveryReport> {
    const historyText = history.map(h => `Q: ${h.question}\nA: ${h.answer}`).join('\n\n');

    const researchResponse = await this.callWithRetry(async (ai) => {
      return await ai.models.generateContent({
        model: SEARCH_MODEL,
        contents: `Perform an exhaustive intelligence synthesis for "${topic}".
        User Profile Context: ${historyText}
        
        Tasks:
        1. Search for 12+ recent breakthroughs or news events.
        2. Find 8+ valid educational YouTube URLs.
        3. Find an extensive list (aim for 200 if possible, minimum 40) of significant academic theories, research papers, or formal publications.
        4. Synthesize a psychological profile of the user based on their answers.`,
        config: {
          tools: [
            { googleSearch: {} }
          ]
        }
      });
    });

    const groundingChunks = researchResponse.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const searchSourcesText = groundingChunks
      .filter(c => c.web)
      .map((c, i) => `[Source ${i}]: Title: ${c.web?.title}, URL: ${c.web?.uri}`)
      .join('\n');

    const reportResponse = await this.callWithRetry(async (ai) => {
      return await ai.models.generateContent({
        model: SYNTHESIS_MODEL,
        contents: `Format the research data into a structured JSON Discovery Report for "${topic}".
        
        User Profile History:
        ${historyText}

        Research Insights:
        ${researchResponse.text}

        Verified Web Sources:
        ${searchSourcesText}
        
        Special Instructions for researchPapers:
        - Aim for up to 200 items. 
        - The 'summary' for each paper must be ultra-concise (max 2-3 sentences).
        - Use bold markdown (e.g. **Method:** or **Finding:**) within the summary to highlight key methodologies or core findings.

        Special Instructions for userPsychology:
        - behavioralInsights: Provide an array of 5-7 punchy points that analyze the user's specific behaviors, biases, and mental models revealed during the session. 
        - Each point MUST use bold markdown (e.g., **Strategic Depth:**) to highlight the core observation.

        JSON Requirements:
        - userPsychology: { profileSummary, dominantTrait, learningStyle, behavioralInsights }
        - news: Array of 12 items.
        - researchPapers: Large array of items. include { title, authors, year, link, summary }. 
        - facts: 10 foundation items.
        - deepResearch: { thematicAnalysis, keyDebates, unansweredQuestions }
        - youtubeVideos: 8+ items.
        - things: { recommendations, misconceptions, challenge, futureOutlook }`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              userPsychology: {
                type: Type.OBJECT,
                properties: {
                  profileSummary: { type: Type.STRING },
                  dominantTrait: { type: Type.STRING },
                  learningStyle: { type: Type.STRING },
                  behavioralInsights: { type: Type.ARRAY, items: { type: Type.STRING } }
                },
                required: ["profileSummary", "dominantTrait", "learningStyle", "behavioralInsights"]
              },
              news: { 
                type: Type.ARRAY, 
                items: { 
                  type: Type.OBJECT, 
                  properties: { 
                    headline: { type: Type.STRING }, 
                    source: { type: Type.STRING }, 
                    summary: { type: Type.STRING }, 
                    relevance: { type: Type.STRING }, 
                    publishedAt: { type: Type.STRING },
                    uri: { type: Type.STRING }
                  }, 
                  required: ["headline", "source", "summary", "relevance", "publishedAt", "uri"] 
                } 
              },
              researchPapers: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    authors: { type: Type.STRING },
                    year: { type: Type.STRING },
                    link: { type: Type.STRING },
                    summary: { type: Type.STRING }
                  },
                  required: ["title", "authors", "year", "link", "summary"]
                }
              },
              facts: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { fact: { type: Type.STRING }, context: { type: Type.STRING } }, required: ["fact", "context"] } },
              deepResearch: { type: Type.OBJECT, properties: { thematicAnalysis: { type: Type.STRING }, keyDebates: { type: Type.ARRAY, items: { type: Type.STRING } }, unansweredQuestions: { type: Type.ARRAY, items: { type: Type.STRING } } }, required: ["thematicAnalysis", "keyDebates", "unansweredQuestions"] },
              things: { type: Type.OBJECT, properties: { recommendations: { type: Type.ARRAY, items: { type: Type.STRING } }, misconceptions: { type: Type.ARRAY, items: { type: Type.STRING } }, challenge: { type: Type.STRING }, futureOutlook: { type: Type.STRING } }, required: ["recommendations", "misconceptions", "challenge", "futureOutlook"] },
              youtubeVideos: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { title: { type: Type.STRING }, url: { type: Type.STRING } }, required: ["title", "url"] } }
            },
            required: ["userPsychology", "news", "facts", "deepResearch", "things", "youtubeVideos", "researchPapers"]
          },
          maxOutputTokens: 12000,
          thinkingConfig: { thinkingBudget: 4000 }
        }
      });
    });

    const report = JSON.parse(reportResponse.text) as DiscoveryReport;
    
    // Improve report image generation by using the most relevant and concise fact
    const bestFact = report.facts.sort((a, b) => a.fact.length - b.fact.length)[0]?.fact || topic;
    report.imageUrl = await this.generateImage(topic, bestFact);

    // Improve YouTube thumbnail fallback mechanism
    if (report.youtubeVideos) {
      report.youtubeVideos = await Promise.all(report.youtubeVideos.map(async v => {
        const embedUrl = this.convertToEmbedUrl(v.url);
        const videoId = embedUrl?.match(/\/embed\/([^/?]+)/)?.[1];
        let thumbnail = videoId ? `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg` : undefined;
        
        if (!thumbnail) {
          // Descriptive fallback prompt for image generation incorporating video title and topic
          const generatedPlaceholder = await this.generateImage(topic, `Visual summary for educational video: "${v.title}". Illustrate the core concept of ${topic} through this lens.`);
          thumbnail = generatedPlaceholder;
        }
        
        return { ...v, embedUrl: embedUrl || '', thumbnail: thumbnail || '' };
      }));
      report.youtubeVideos = report.youtubeVideos.filter(v => v.embedUrl !== '');
    }

    return report;
  }
}
