
import React, { useState, useEffect, useMemo } from 'react';
import { DiscoveryReport, YouTubeVideo, ResearchPaper } from '../types';

interface Props {
  topic: string;
  report: DiscoveryReport;
  onRestart: () => void;
}

type TabType = 'overview' | 'feed' | 'analysis' | 'media' | 'academic';
type SortType = 'newest' | 'oldest' | 'title-asc' | 'title-desc';

const ReportView: React.FC<Props> = ({ topic, report, onRestart }) => {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [visibleNews, setVisibleNews] = useState(8);
  const [visibleVideos, setVisibleVideos] = useState(6);
  const [visiblePapers, setVisiblePapers] = useState(30); // Increased initial papers
  const [activeVideo, setActiveVideo] = useState<YouTubeVideo | null>(null);
  
  // Academic Filtering/Sorting State
  const [academicSearch, setAcademicSearch] = useState('');
  const [academicSort, setAcademicSort] = useState<SortType>('newest');

  const tabs: { id: TabType; label: string; icon: React.ReactNode }[] = [
    { 
      id: 'overview', 
      label: 'Personalized Overview', 
      icon: <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg> 
    },
    { 
      id: 'feed', 
      label: 'Global Breakthroughs', 
      icon: <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" /></svg> 
    },
    { 
      id: 'analysis', 
      label: 'Deep Intelligence', 
      icon: <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0012 18.75V19a2 2 0 11-4 0v-.25c0-.468-.175-.927-.492-1.253l-.548-.547z" /></svg> 
    },
    { 
      id: 'media', 
      label: 'Educational Media', 
      icon: <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg> 
    },
    { 
      id: 'academic', 
      label: 'Research Repository', 
      icon: <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg> 
    }
  ];

  const sortedNews = useMemo(() => {
    return [...report.news].sort((a, b) => {
      const dateA = new Date(a.publishedAt).getTime() || 0;
      const dateB = new Date(b.publishedAt).getTime() || 0;
      return dateB - dateA;
    });
  }, [report.news]);

  const filteredAndSortedPapers = useMemo(() => {
    let papers = [...report.researchPapers];
    
    // Filtering
    if (academicSearch.trim()) {
      const query = academicSearch.toLowerCase();
      papers = papers.filter(p => 
        p.title.toLowerCase().includes(query) || 
        p.summary.toLowerCase().includes(query) ||
        p.authors.toLowerCase().includes(query)
      );
    }

    // Sorting
    papers.sort((a, b) => {
      switch (academicSort) {
        case 'newest': return parseInt(b.year) - parseInt(a.year);
        case 'oldest': return parseInt(a.year) - parseInt(b.year);
        case 'title-asc': return a.title.localeCompare(b.title);
        case 'title-desc': return b.title.localeCompare(a.title);
        default: return 0;
      }
    });

    return papers;
  }, [report.researchPapers, academicSearch, academicSort]);

  const getSourceStyle = (source: string) => {
    const s = source.toLowerCase();
    if (s.includes('tech') || s.includes('mit') || s.includes('wired')) return 'bg-blue-50 text-blue-600 border-blue-100';
    if (s.includes('science') || s.includes('nature') || s.includes('phys')) return 'bg-emerald-50 text-emerald-600 border-emerald-100';
    if (s.includes('news') || s.includes('times') || s.includes('post')) return 'bg-slate-50 text-slate-600 border-slate-200';
    if (s.includes('edu') || s.includes('uni') || s.includes('stanford')) return 'bg-indigo-50 text-indigo-600 border-indigo-100';
    return 'bg-amber-50 text-amber-600 border-amber-100';
  };

  useEffect(() => {
    if (activeVideo) document.body.style.overflow = 'hidden';
    else document.body.style.overflow = 'auto';
  }, [activeVideo]);

  const handleExportPDF = () => {
    window.print();
  };

  const renderHighlightedText = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        const word = part.slice(2, -2);
        return <span key={i} className="inline-block px-1.5 py-0.5 bg-blue-100 text-blue-800 rounded-md font-bold mx-0.5 shadow-sm">{word}</span>;
      }
      return <span key={i}>{part}</span>;
    });
  };

  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
    } catch {
      return dateStr;
    }
  };

  // Section Renderers
  const renderOverview = () => (
    <div className="space-y-16 animate-in fade-in duration-700">
      {/* Mental Model & Summary */}
      <section className="p-8 md:p-12 bg-white rounded-[3rem] border border-slate-100 shadow-xl grid grid-cols-1 lg:grid-cols-4 gap-12 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-50/50 rounded-full -mr-32 -mt-32 blur-3xl" />
        <div className="lg:col-span-3 space-y-6 relative">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center text-xs font-black shadow-lg shadow-blue-200">P</div>
            <h2 className="text-[11px] font-black uppercase tracking-[0.5em] text-blue-600/60">Cognitive Mental Model</h2>
          </div>
          <div className="text-3xl md:text-4xl serif-title leading-tight text-slate-900 font-light">
            {renderHighlightedText(report.userPsychology.profileSummary)}
          </div>
        </div>
        <div className="flex flex-col justify-center gap-6 border-l border-slate-100 pl-10 relative">
          <div>
            <span className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-300 block mb-1">Dominant Trait</span>
            <span className="text-xl font-bold text-blue-600">{report.userPsychology.dominantTrait}</span>
          </div>
          <div>
            <span className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-300 block mb-1">Learning Vector</span>
            <span className="text-xl font-bold text-slate-800">{report.userPsychology.learningStyle}</span>
          </div>
        </div>
      </section>

      {/* Behavioral Analysis Points */}
      <section className="space-y-10">
        <div className="flex items-center gap-4 px-6">
          <h3 className="text-[11px] font-black uppercase tracking-[0.4em] text-slate-400">Behavioral Profile Analysis</h3>
          <div className="flex-1 h-[1px] bg-slate-100" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 px-6">
          {(report.userPsychology.behavioralInsights || []).map((insight, idx) => (
            <div key={idx} className="flex gap-6 items-start p-8 bg-white rounded-[2.5rem] border border-slate-50 shadow-sm hover:shadow-md transition-shadow group">
              <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center flex-shrink-0 group-hover:bg-blue-50 transition-colors">
                <span className="text-xs font-black text-slate-300 group-hover:text-blue-400 transition-colors">0{idx + 1}</span>
              </div>
              <div className="text-lg text-slate-600 leading-relaxed font-light">
                {renderHighlightedText(insight)}
              </div>
            </div>
          ))}
        </div>
      </section>

      {report.imageUrl && (
        <section className="rounded-[4rem] overflow-hidden shadow-2xl border-4 border-white aspect-[21/9] relative group">
          <img src={report.imageUrl} alt={topic} className="w-full h-full object-cover transition-transform duration-[5s] group-hover:scale-105" />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent pointer-events-none" />
          <div className="absolute bottom-10 left-10 text-white space-y-2">
            <p className="text-[10px] font-black uppercase tracking-[0.4em] opacity-60">Synthesis visualization</p>
            <h3 className="text-3xl serif-title capitalize tracking-tight">{topic}</h3>
          </div>
        </section>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {report.facts.map((fact, idx) => (
          <div key={idx} className={`p-12 rounded-[3.5rem] border transition-all duration-700 group hover:-translate-y-2 ${idx === 0 ? 'bg-slate-900 text-white border-slate-800 md:col-span-2 shadow-2xl' : 'bg-white text-slate-900 border-slate-100 shadow-sm'}`}>
            <p className={`serif-title leading-[1.1] mb-10 tracking-tight ${idx === 0 ? 'text-4xl md:text-6xl font-light' : 'text-3xl'}`}>"{fact.fact}"</p>
            <div className="flex items-center gap-6">
              <div className={`h-[1px] w-16 ${idx === 0 ? 'bg-blue-600' : 'bg-slate-200'}`} />
              <span className={`text-[10px] uppercase tracking-[0.4em] font-black ${idx === 0 ? 'text-blue-500' : 'text-slate-400'}`}>{fact.context}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderNews = () => (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {sortedNews.slice(0, visibleNews).map((item, i) => (
          <article 
            key={i} 
            className="group p-10 bg-white rounded-[3rem] border border-slate-100 shadow-sm transition-all duration-500 flex flex-col hover:shadow-2xl hover:border-blue-100 h-full"
          >
            <div className="flex items-center justify-between mb-6">
              <div className={`px-4 py-1.5 border rounded-xl text-[10px] font-black uppercase tracking-widest shadow-sm transition-colors ${getSourceStyle(item.source)}`}>
                {item.source}
              </div>
              <time className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">{formatDate(item.publishedAt)}</time>
            </div>
            <h4 className="text-2xl font-bold text-slate-900 mb-6 leading-tight group-hover:text-blue-600 transition-colors">{item.headline}</h4>
            <p className="text-slate-500 text-base font-light leading-relaxed mb-8 flex-grow">{item.summary}</p>
            <div className="mt-auto pt-6 border-t border-slate-50 flex items-center justify-between">
              <div className="text-[10px] text-slate-400 font-medium italic leading-snug max-w-[60%]">{item.relevance}</div>
              {item.uri && (
                <a 
                  href={item.uri} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="flex items-center gap-2 text-[11px] font-black text-blue-600 uppercase tracking-[0.2em] group/btn hover:text-blue-800 transition-all"
                >
                  READ MORE
                  <span className="transform group-hover/btn:translate-x-1 transition-transform">↗</span>
                </a>
              )}
            </div>
          </article>
        ))}
      </div>
      {sortedNews.length > visibleNews && (
        <button onClick={() => setVisibleNews(v => v + 6)} className="no-print w-full py-8 rounded-[2.5rem] border-2 border-dashed border-slate-200 text-slate-400 font-black text-xs hover:border-blue-400 hover:text-blue-600 transition-all uppercase tracking-[0.3em]">Expand Intelligence Feed</button>
      )}
    </div>
  );

  const renderAnalysis = () => (
    <div className="space-y-16 animate-in fade-in duration-700">
      <section className="bg-slate-900 rounded-[4rem] p-12 md:p-20 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-600/10 rounded-full -ml-48 -mb-48 blur-3xl" />
        <div className="space-y-12 relative">
          <h3 className="text-[11px] font-black uppercase tracking-[0.6em] text-blue-400">Synthesis Engine Output</h3>
          <p className="text-4xl md:text-5xl serif-title leading-[1.2] font-light text-slate-100 tracking-tight">{report.deepResearch.thematicAnalysis}</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 pt-16 border-t border-white/10">
            <div className="space-y-8">
              <h4 className="text-[10px] font-black text-white/30 uppercase tracking-[0.5em]">Active Debates</h4>
              <div className="space-y-6">
                {report.deepResearch.keyDebates.map((d, i) => (
                  <div key={i} className="flex gap-5 text-lg text-slate-300 font-light leading-snug"><span className="text-blue-500 font-black text-xl">/</span> {d}</div>
                ))}
              </div>
            </div>
            <div className="space-y-8">
              <h4 className="text-[10px] font-black text-white/30 uppercase tracking-[0.5em]">Unanswered Questions</h4>
              <div className="space-y-6">
                {report.deepResearch.unansweredQuestions.map((q, i) => (
                  <div key={i} className="flex gap-5 text-lg text-slate-300 font-light leading-snug italic"><span className="text-emerald-500 font-black text-xl">?</span> {q}</div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
         <div className="bg-white rounded-[3.5rem] p-12 border border-slate-50 shadow-sm space-y-6">
            <h4 className="text-[10px] font-black text-slate-300 uppercase tracking-[0.5em]">Future Trajectory</h4>
            <p className="text-xl text-slate-700 leading-relaxed font-light italic">"{report.things.futureOutlook}"</p>
         </div>
         <div className="bg-white rounded-[3.5rem] p-12 border border-slate-50 shadow-sm space-y-6">
            <h4 className="text-[10px] font-black text-slate-300 uppercase tracking-[0.5em]">Systemic Challenge</h4>
            <p className="text-xl text-slate-700 leading-relaxed font-light">{report.things.challenge}</p>
         </div>
      </div>
    </div>
  );

  const renderAcademic = () => (
    <div className="space-y-12 animate-in fade-in duration-700">
      {/* Filtering and Sorting Controls */}
      <div className="flex flex-col md:flex-row gap-6 p-10 bg-white rounded-[2.5rem] shadow-sm border border-slate-100 no-print">
        <div className="flex-1 relative">
          <input 
            type="text" 
            placeholder="Search within research papers..."
            value={academicSearch}
            onChange={(e) => setAcademicSearch(e.target.value)}
            className="w-full h-16 pl-14 pr-6 rounded-2xl bg-slate-50 border-2 border-transparent focus:border-indigo-500 focus:bg-white outline-none transition-all text-slate-700"
          />
          <svg className="w-6 h-6 text-slate-300 absolute left-5 top-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
        </div>
        <div className="md:w-64">
          <select 
            value={academicSort}
            onChange={(e) => setAcademicSort(e.target.value as SortType)}
            className="w-full h-16 px-6 rounded-2xl bg-slate-50 border-2 border-transparent focus:border-indigo-500 outline-none transition-all text-[11px] font-black uppercase tracking-widest text-slate-600 appearance-none"
          >
            <option value="newest">Year: Newest First</option>
            <option value="oldest">Year: Oldest First</option>
            <option value="title-asc">Title: A-Z</option>
            <option value="title-desc">Title: Z-A</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredAndSortedPapers.slice(0, visiblePapers).map((paper, idx) => (
          <div key={idx} className="group p-10 bg-white rounded-[3rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:border-indigo-100 transition-all flex flex-col h-full relative overflow-hidden">
            <div className="absolute top-0 right-0 p-6 opacity-0 group-hover:opacity-100 transition-opacity">
              <svg className="w-5 h-5 text-indigo-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
            </div>
            <div className="flex items-center justify-between mb-6">
              <span className="text-[10px] font-black text-indigo-600 bg-indigo-50 px-4 py-1.5 rounded-full uppercase tracking-widest shadow-sm">White Paper</span>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{paper.year}</span>
            </div>
            <h4 className="text-2xl font-bold text-slate-900 mb-4 leading-tight">
              <a href={paper.link} target="_blank" rel="noopener noreferrer" className="hover:text-indigo-600 transition-colors block">
                {paper.title}
              </a>
            </h4>
            <p className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] mb-8">{paper.authors}</p>
            <p className="text-slate-600 text-base font-light leading-relaxed mb-10 flex-grow">
              {renderHighlightedText(paper.summary)}
            </p>
            <div className="pt-8 border-t border-slate-50">
              <a 
                href={paper.link} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="inline-flex items-center gap-2 text-[11px] font-black text-indigo-500 uppercase tracking-[0.2em] group/btn hover:text-indigo-700 transition-colors"
              >
                ACCESS PUBLICATION
                <span className="transform group-hover/btn:translate-x-1 transition-transform">↗</span>
              </a>
            </div>
          </div>
        ))}
      </div>
      {filteredAndSortedPapers.length > visiblePapers && (
        <button onClick={() => setVisiblePapers(v => v + 30)} className="no-print w-full py-8 rounded-[2.5rem] border-2 border-dashed border-slate-200 text-slate-400 font-black text-xs hover:border-indigo-400 hover:text-indigo-600 transition-all uppercase tracking-[0.3em]">Load More Publications ({filteredAndSortedPapers.length - visiblePapers} remaining)</button>
      )}
    </div>
  );

  const renderMedia = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 animate-in fade-in duration-700">
      {(report.youtubeVideos || []).slice(0, visibleVideos).map((video, idx) => (
        <div key={idx} className="group relative bg-white rounded-[3.5rem] overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-700 cursor-pointer" onClick={() => setActiveVideo(video)}>
          <div className="aspect-video relative overflow-hidden bg-slate-900">
            <img 
              src={video.thumbnail || "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=800"} 
              alt={video.title} 
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[2s]" 
            />
            <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-all duration-500 flex items-center justify-center">
              <div className="w-20 h-20 bg-white/20 backdrop-blur-md border border-white/30 rounded-full flex items-center justify-center shadow-2xl scale-75 group-hover:scale-100 transition-transform duration-500">
                <svg className="h-10 w-10 text-white ml-1" viewBox="0 0 20 20" fill="currentColor"><path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" /></svg>
              </div>
            </div>
          </div>
          <div className="p-10">
            <h4 className="font-bold text-slate-800 text-xl leading-tight group-hover:text-blue-600 transition-colors">{video.title}</h4>
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="report-container max-w-[1500px] w-full mx-auto py-12 md:py-24 px-6 md:px-12 space-y-20 animate-in fade-in duration-1000 relative">
      {/* Video Modal */}
      {activeVideo && (
        <div className="no-print fixed inset-0 z-[100] bg-black/98 flex flex-col items-center justify-center p-4 md:p-12 animate-in fade-in duration-500" onClick={() => setActiveVideo(null)}>
           <button className="absolute top-10 right-10 text-white/30 hover:text-white transition-all font-black text-xs tracking-[0.5em]">CLOSE COMMAND [ESC]</button>
           <div className="w-full max-w-7xl aspect-video rounded-[3rem] overflow-hidden bg-black shadow-2xl border border-white/5" onClick={e => e.stopPropagation()}>
             <iframe src={activeVideo.embedUrl} className="w-full h-full" allowFullScreen title={activeVideo.title} />
           </div>
           <h4 className="mt-12 text-white text-4xl serif-title text-center px-10 font-light tracking-tight">{activeVideo.title}</h4>
        </div>
      )}

      {/* Hero Header */}
      <header className="flex flex-col lg:flex-row lg:items-end justify-between gap-16 border-b border-slate-100 pb-20">
        <div className="space-y-8 max-w-5xl">
          <div className="flex items-center gap-6">
            <span className="h-[2px] w-20 bg-blue-600"></span>
            <span className="text-[11px] font-black uppercase tracking-[0.6em] text-blue-600/80">Socratic Discovery Brief : Alpha v1.4</span>
          </div>
          <h1 className="serif-title text-8xl md:text-[10rem] text-slate-900 leading-[0.75] tracking-tighter capitalize font-light">
            {topic}<span className="text-blue-600">.</span>
          </h1>
          <p className="text-slate-400 text-2xl font-light leading-relaxed max-w-2xl border-l-4 border-blue-50 pl-10">
            Synthesizing breakthroughs in <span className="text-slate-800 font-medium">global research</span>, <span className="text-slate-800 font-medium">market trends</span>, and <span className="text-slate-800 font-medium">academic theory</span>.
          </p>
        </div>
        <div className="no-print flex flex-col sm:flex-row gap-6">
          <button 
            onClick={handleExportPDF}
            className="h-20 px-12 bg-white border border-slate-200 text-slate-900 rounded-[2rem] font-black text-[11px] tracking-[0.3em] shadow-sm hover:border-blue-500 hover:text-blue-600 transition-all flex items-center justify-center gap-3 uppercase"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
            Export Dossier
          </button>
          <button 
            onClick={onRestart}
            className="h-20 px-12 bg-slate-900 text-white rounded-[2rem] font-black text-[11px] tracking-[0.3em] shadow-2xl hover:bg-blue-600 transition-all active:scale-95 flex items-center justify-center gap-3 uppercase"
          >
            Reset Engine
          </button>
        </div>
      </header>

      {/* Premium Tabbed Navigation */}
      <nav className="no-print sticky top-6 z-50 bg-white/70 backdrop-blur-3xl border border-slate-100 rounded-[2.5rem] p-2 shadow-2xl max-w-fit mx-auto">
        <div className="flex items-center gap-1">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-3 px-8 py-5 rounded-[2rem] text-[11px] font-black uppercase tracking-[0.2em] transition-all whitespace-nowrap
                ${activeTab === tab.id ? 'bg-blue-600 text-white shadow-xl shadow-blue-200' : 'text-slate-400 hover:text-slate-900 hover:bg-slate-50'}`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>
      </nav>

      {/* Main Content Area */}
      <div className="relative min-h-[70vh]">
        <div className="no-print">
          {activeTab === 'overview' && renderOverview()}
          {activeTab === 'feed' && renderNews()}
          {activeTab === 'analysis' && renderAnalysis()}
          {activeTab === 'media' && renderMedia()}
          {activeTab === 'academic' && renderAcademic()}
        </div>

        {/* Global Print Layout (All Sections) */}
        <div className="print-only space-y-32">
          <div className="space-y-16">
            <h2 className="text-5xl serif-title border-b-8 border-blue-600 pb-6 tracking-tighter">I. Cognitive Foundation</h2>
            {renderOverview()}
          </div>
          <div className="page-break pt-20 space-y-16">
            <h2 className="text-5xl serif-title border-b-8 border-emerald-500 pb-6 tracking-tighter">II. Breakthrough Intelligence</h2>
            {renderNews()}
          </div>
          <div className="page-break pt-20 space-y-16">
            <h2 className="text-5xl serif-title border-b-8 border-blue-400 pb-6 tracking-tighter">III. Deep Analysis</h2>
            {renderAnalysis()}
          </div>
          <div className="page-break pt-20 space-y-16">
            <h2 className="text-5xl serif-title border-b-8 border-indigo-600 pb-6 tracking-tighter">IV. Academic Framework</h2>
            {renderAcademic()}
          </div>
        </div>
      </div>

      <footer className="pt-40 pb-20 border-t border-slate-100 text-center space-y-8">
        <p className="text-[11px] font-black text-slate-300 uppercase tracking-[1.2em]">Omni-Learner Assistant • Synthesis Engine • Powered by Gemini Ultra</p>
        <div className="flex justify-center gap-4 text-[9px] font-bold text-slate-300 uppercase tracking-widest">
           <span>Privacy Encrypted</span>
           <span className="opacity-30">|</span>
           <span>Neural Architecture</span>
           <span className="opacity-30">|</span>
           <span>v1.4.2</span>
        </div>
      </footer>
    </div>
  );
};

export default ReportView;
