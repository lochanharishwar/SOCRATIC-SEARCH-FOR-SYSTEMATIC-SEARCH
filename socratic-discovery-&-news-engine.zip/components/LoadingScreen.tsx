
import React, { useEffect, useState } from 'react';

const LoadingScreen: React.FC<{ topic: string }> = ({ topic }) => {
  const [messageIndex, setMessageIndex] = useState(0);
  const messages = [
    "Mapping cognitive nodes...",
    "Querying global live intelligence...",
    "Filtering breakthrough signals...",
    "Connecting behavioral patterns...",
    "Synthesizing the Discovery Brief..."
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setMessageIndex(prev => (prev + 1) % messages.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="text-center space-y-12 max-w-xl mx-auto p-12">
      <div className="relative inline-block" style={{ perspective: '1000px' }}>
        <style>
          {`
            @keyframes rotate3d {
              0% { transform: rotateY(0deg) rotateX(20deg); }
              100% { transform: rotateY(360deg) rotateX(20deg); }
            }
            .spinner-3d {
              animation: rotate3d 12s linear infinite;
              transform-style: preserve-3d;
            }
          `}
        </style>
        <div className="w-40 h-40 rounded-full border-[6px] border-slate-100 border-t-blue-600 spinner-3d relative">
          <div className="absolute inset-2 rounded-full border-2 border-indigo-100 border-b-indigo-400 opacity-50"></div>
        </div>
        <div className="absolute inset-0 flex items-center justify-center" style={{ transform: 'translateZ(20px)' }}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-blue-600 animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
        </div>
      </div>
      
      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-slate-800 tracking-tight">Synthesis in Progress</h2>
        <p className="text-blue-600 font-medium text-lg min-h-[1.5rem] transition-all">
          {messages[messageIndex]}
        </p>
        <div className="flex justify-center gap-1.5 pt-4">
           {messages.map((_, i) => (
             <div key={i} className={`h-1 rounded-full transition-all duration-500 ${i === messageIndex ? 'bg-blue-600 w-8' : 'bg-slate-200 w-4'}`} />
           ))}
        </div>
        <p className="text-xs text-slate-400 font-mono pt-4 uppercase tracking-widest">
          Topic: <span className="text-slate-600 font-bold">{topic}</span>
        </p>
      </div>

      <div className="bg-white border border-slate-100 rounded-3xl p-8 shadow-sm text-sm text-slate-500 leading-relaxed text-left italic">
        "Knowledge is built by questions, not by answers." The engine is currently correlating your unique Socratic trail with real-time global discoveries.
      </div>
    </div>
  );
};

export default LoadingScreen;
