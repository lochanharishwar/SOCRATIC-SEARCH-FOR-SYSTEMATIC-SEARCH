
import React, { useState, useMemo } from 'react';

interface Props {
  onStart: (topic: string) => void;
}

const LandingView: React.FC<Props> = ({ onStart }) => {
  const [topic, setTopic] = useState('');

  const suggestions = useMemo(() => {
    const list = [
      "Quantum Computing", "The Fall of the Roman Empire", "Micro-biology", 
      "Philosophy of Existentialism", "Renewable Energy Economics", 
      "Large Language Models", "Urban Vertical Farming", "17th Century Coffeehouses",
      "Mars Colonization Ethics", "The Great Barrier Reef Ecology"
    ];
    return list.sort(() => 0.5 - Math.random()).slice(0, 5);
  }, []);

  return (
    <section className="max-w-3xl w-full text-center space-y-8 py-12" aria-labelledby="landing-title">
      <div className="space-y-4">
        <h1 id="landing-title" className="serif-title text-5xl md:text-7xl text-slate-800 tracking-tight leading-tight">
          Socratic Discovery <br/>
          <span className="text-blue-600" aria-hidden="true">& News Engine</span>
        </h1>
        <p className="text-lg text-slate-500 max-w-xl mx-auto font-light leading-relaxed">
          The Insightful Mentor engages your mind through critical inquiry before synthesizing a bespoke landscape of current breakthroughs and deep facts.
        </p>
      </div>

      <div className="relative group max-w-2xl mx-auto" role="search">
        <label htmlFor="topic-input" className="sr-only">Enter a topic to explore</label>
        <input 
          id="topic-input"
          type="text"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && topic.trim() && onStart(topic)}
          placeholder="Enter a topic you wish to explore..."
          className="w-full px-6 py-5 text-xl rounded-2xl border-2 border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 outline-none transition-all shadow-sm"
          aria-required="true"
        />
        <button 
          onClick={() => topic.trim() && onStart(topic)}
          disabled={!topic.trim()}
          aria-label="Start inquiry session"
          className="absolute right-3 top-3 bottom-3 bg-blue-600 text-white px-8 rounded-xl font-semibold hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors"
        >
          Begin
        </button>
      </div>

      <div className="flex flex-wrap justify-center gap-3 pt-4" aria-label="Quick start suggestions">
        {suggestions.map((s) => (
          <button 
            key={s}
            onClick={() => onStart(s)}
            className="px-4 py-2 bg-white border border-slate-200 rounded-full text-sm text-slate-600 hover:border-blue-400 hover:text-blue-600 transition-all shadow-sm focus:ring-2 focus:ring-blue-500 outline-none"
          >
            {s}
          </button>
        ))}
      </div>

      <div className="pt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
        <div className="p-6 bg-white rounded-2xl shadow-sm border border-slate-100">
          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600 mb-4" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h3 className="font-bold text-slate-800 mb-2 text-lg">Inquiry First</h3>
          <p className="text-slate-500 text-sm leading-relaxed">Instead of data dumps, we ask. We map your knowledge to deliver information at the perfect depth.</p>
        </div>
        <div className="p-6 bg-white rounded-2xl shadow-sm border border-slate-100">
          <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center text-indigo-600 mb-4" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
            </svg>
          </div>
          <h3 className="font-bold text-slate-800 mb-2 text-lg">Real-time News</h3>
          <p className="text-slate-500 text-sm leading-relaxed">Integrated search grounding ensures your report includes the very latest breakthroughs and trends.</p>
        </div>
        <div className="p-6 bg-white rounded-2xl shadow-sm border border-slate-100">
          <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center text-teal-600 mb-4" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04kM12 21.48l.348-.13c2.635-.97 4.674-2.8 5.718-5.122A11.966 11.966 0 0112 18.026a11.966 11.966 0 01-6.066-1.798c1.044 2.322 3.083 4.152 5.718 5.122l.348.13z" />
            </svg>
          </div>
          <h3 className="font-bold text-slate-800 mb-2 text-lg">Visual Insights</h3>
          <p className="text-slate-500 text-sm leading-relaxed">Experience learning with AI-generated images and cinematic visualizations that bring concepts to life.</p>
        </div>
      </div>
    </section>
  );
};

export default LandingView;
