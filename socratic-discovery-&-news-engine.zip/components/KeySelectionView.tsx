
import React from 'react';

interface Props {
  onKeySelected: () => void;
  onCancel: () => void;
}

const KeySelectionView: React.FC<Props> = ({ onKeySelected, onCancel }) => {
  const handleOpenKey = async () => {
    try {
      // @ts-ignore
      await window.aistudio.openSelectKey();
      // Proceed to the app immediately as per guidelines to avoid race conditions
      onKeySelected();
    } catch (e) {
      console.error("Failed to open key selection:", e);
    }
  };

  return (
    <div className="max-w-md w-full bg-white p-10 rounded-3xl shadow-2xl text-center space-y-6 border border-slate-100 animate-in fade-in zoom-in duration-300">
      <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600 mx-auto">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
        </svg>
      </div>
      <div className="space-y-2">
        <h2 className="text-2xl font-bold text-slate-800 tracking-tight">API Quota Management</h2>
        <p className="text-slate-500 text-sm leading-relaxed">
          The Socratic Engine is currently experiencing high demand. To continue with priority access and avoid "Limit Exceeded" errors, please use your own API key.
        </p>
      </div>
      
      <div className="bg-blue-50/50 p-4 rounded-2xl text-left space-y-2 border border-blue-100">
        <h4 className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Why use your own key?</h4>
        <ul className="text-xs text-slate-600 space-y-1">
          <li className="flex items-center gap-2">
            <span className="w-1 h-1 bg-blue-400 rounded-full"></span>
            Bypass global shared rate limits (429)
          </li>
          <li className="flex items-center gap-2">
            <span className="w-1 h-1 bg-blue-400 rounded-full"></span>
            Unlock high-resolution AI visualizations
          </li>
          <li className="flex items-center gap-2">
            <span className="w-1 h-1 bg-blue-400 rounded-full"></span>
            Access advanced Synthesis (Pro models)
          </li>
        </ul>
      </div>

      <div className="flex flex-col gap-3 pt-2">
        <button 
          onClick={handleOpenKey}
          className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 active:scale-[0.98]"
        >
          Select Priority API Key
        </button>
        <button 
          onClick={onCancel}
          className="w-full bg-slate-50 text-slate-400 py-4 rounded-xl font-bold hover:bg-slate-100 transition-all text-xs uppercase tracking-widest"
        >
          Back to Landing
        </button>
      </div>
      
      <p className="text-[10px] text-slate-400">
        Learn about <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" className="text-blue-500 underline">API billing and quotas</a>.
      </p>
    </div>
  );
};

export default KeySelectionView;
