
import React, { useState, useEffect, useRef } from 'react';
import { ConversationState, AnswerLog } from '../types';

interface Props {
  state: ConversationState;
  currentQuestion: string;
  validation: string;
  onAnswer: (answer: string) => void;
  onSkip: () => void;
  isThinking: boolean;
}

const DRAFT_KEY = 'socratic_draft_buffer';

const InquiryView: React.FC<Props> = ({ state, currentQuestion, validation, onAnswer, onSkip, isThinking }) => {
  const [answer, setAnswer] = useState('');
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Keyboard shortcut for skipping (Alt + S)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && e.key.toLowerCase() === 's') {
        if (!answer.trim() && !isThinking) {
          e.preventDefault();
          onSkip();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [answer, isThinking, onSkip]);

  // Draft auto-save logic
  useEffect(() => {
    const savedDraft = localStorage.getItem(DRAFT_KEY);
    if (savedDraft) setAnswer(savedDraft);
  }, []);

  useEffect(() => {
    localStorage.setItem(DRAFT_KEY, answer);
  }, [answer]);

  // Handle auto-scrolling
  useEffect(() => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTo({
        top: scrollContainerRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
    if (!isThinking) {
      inputRef.current?.focus();
    }
  }, [isThinking, currentQuestion, state.userAnswers, validation]);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (answer.trim() && !isThinking) {
      onAnswer(answer);
      setAnswer('');
      localStorage.removeItem(DRAFT_KEY);
    }
  };

  const renderUserAnswer = (text: string) => {
    const words = text.split(/\s+/);
    const highlightRegex = /^(understand|research|believe|interest|challenge|future|critical|important|complex|simple|fundamental|system|logic|theory|dynamic|potential|impact|strategy|focus)/i;
    
    return words.map((word, i) => {
      const cleanWord = word.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, "");
      const isKey = cleanWord.length > 8 || highlightRegex.test(cleanWord);
      
      if (isKey) {
        return (
          <span key={i} className="inline-block">
            <span className="bg-amber-50 text-amber-700 px-1 rounded border-b border-amber-200 font-semibold mx-0.5">
              {word}
            </span>
            {" "}
          </span>
        );
      }
      return <span key={i}>{word} </span>;
    });
  };

  const progress = (state.currentQuestionIndex / state.totalQuestions) * 100;

  return (
    <section className="max-w-3xl w-full flex flex-col h-[85vh] max-h-[85vh] bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden" aria-label="Socratic Inquiry Session">
      {/* Progress Header - Fixed */}
      <header className="p-6 bg-slate-50 border-b border-slate-100 flex-shrink-0" role="banner">
        <div className="flex justify-between items-center mb-2">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Psychological Analysis
          </h2>
          <span className="text-xs font-bold text-blue-600" aria-current="step">
            {state.currentQuestionIndex} / {state.totalQuestions} Perspectives
          </span>
        </div>
        <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden" role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100} aria-label="Inquiry Progress">
          <div 
            className="h-full bg-blue-600 transition-all duration-700 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
      </header>

      {/* Chat Area - Purely Scrollable Container */}
      <div 
        ref={scrollContainerRef}
        className="flex-1 overflow-y-auto p-8 space-y-8 scroll-smooth scrollbar-thin scrollbar-thumb-slate-200 bg-white" 
        aria-live="polite" 
        role="log"
      >
        <div className="flex flex-col gap-8 min-h-full">
          {state.userAnswers.map((log, i) => (
            <React.Fragment key={i}>
              <div className="flex items-start gap-4 opacity-40">
                <div className="w-8 h-8 rounded-full bg-blue-50 flex items-center justify-center flex-shrink-0">
                  <span className="text-xs font-bold text-blue-300">Q</span>
                </div>
                <div className="text-lg text-slate-400 font-light">{log.question}</div>
              </div>
              <div className="flex flex-row-reverse items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center flex-shrink-0">
                  <span className="text-xs font-bold text-slate-400">U</span>
                </div>
                <div className="bg-slate-50 p-4 rounded-2xl rounded-tr-none border border-slate-100 text-slate-600 text-right max-w-[80%] shadow-sm">
                  {renderUserAnswer(log.answer)}
                </div>
              </div>
            </React.Fragment>
          ))}

          {validation && (
            <div className="flex items-start gap-4 animate-in fade-in slide-in-from-top-4 duration-500" role="status">
              <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center flex-shrink-0" aria-hidden="true">
                <span className="text-xs font-bold text-slate-500">IM</span>
              </div>
              <div className="bg-blue-50/30 p-5 rounded-2xl rounded-tl-none border border-blue-100 text-slate-700 italic leading-relaxed shadow-sm">
                <span className="sr-only">Mentor Feedback: </span>
                {validation}
              </div>
            </div>
          )}

          {currentQuestion && (
            <div className="flex items-start gap-4 animate-in fade-in slide-in-from-left-4 duration-500">
               <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0" aria-hidden="true">
                <span className="text-xs font-bold text-blue-600">Q</span>
              </div>
              <div className="text-2xl font-medium text-slate-800 leading-tight">
                <span className="sr-only">Mentor Inquiry: </span>
                {currentQuestion}
              </div>
            </div>
          )}

          {isThinking && (
            <div className="flex items-center gap-3 text-slate-400 py-4" aria-busy="true" aria-label="Reflecting">
              <div className="flex gap-1" aria-hidden="true">
                <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce"></div>
              </div>
              <span className="text-sm font-medium">Processing cognitive links...</span>
            </div>
          )}
          <div ref={chatEndRef} className="h-4 w-full" />
        </div>
      </div>

      {/* Input Area - Fixed */}
      <footer className="p-6 border-t border-slate-100 bg-white flex-shrink-0">
        <form onSubmit={handleSubmit} className="relative">
          <label htmlFor="answer-input" className="sr-only">Provide your response</label>
          <textarea
            id="answer-input"
            ref={inputRef}
            rows={2}
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            disabled={isThinking}
            placeholder="Share your perspective..."
            className="w-full px-5 py-4 pr-44 bg-slate-50 rounded-2xl border-2 border-transparent focus:border-blue-500 outline-none transition-all resize-none text-lg text-slate-800 disabled:opacity-50"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSubmit();
              }
            }}
          />
          <div className="absolute right-3 bottom-3 flex gap-3">
            {!answer.trim() && !isThinking && (
              <button
                type="button"
                onClick={(e) => {
                   e.preventDefault();
                   onSkip();
                }}
                title="Skip this question (Alt+S)"
                className="px-5 py-3 border-2 border-amber-200 text-amber-600 rounded-xl hover:bg-amber-50 font-black text-[10px] transition-all uppercase tracking-[0.2em] shadow-sm active:scale-95"
              >
                Skip Step
              </button>
            )}
            <button
              type="submit"
              disabled={!answer.trim() || isThinking}
              aria-label="Submit Response"
              className="p-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 disabled:bg-slate-300 transition-all shadow-lg shadow-blue-200 active:scale-95"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
            </button>
          </div>
        </form>
        <div className="flex justify-between items-center mt-3 px-1">
          <p className="text-xs text-slate-400 italic">Drafts are auto-saved.</p>
          <p className="text-[10px] text-slate-300 font-bold uppercase tracking-widest hidden md:block">Alt + S to Skip • Enter to Send</p>
        </div>
      </footer>
    </section>
  );
};

export default InquiryView;
